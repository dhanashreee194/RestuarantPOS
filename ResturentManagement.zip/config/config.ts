import { Secret } from "jsonwebtoken";

export const SECRET_KEY: Secret = 'jcefhfurhchasjxbwedgyewgdqewbytewyudqewdqed6qs8732e234e2346hg';
export const DB_URL:string =""
export const DB_URL_DEV:string ="localhost:27017";

export const DB_NAME:string="RCMSDB"