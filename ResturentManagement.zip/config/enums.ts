export enum USER_ROLES {
  DEFAULT = 0,
  EMOPLOYEE, // for kitchen management
  ADMIN, // user management
  SUPER_ADMIN, // full access
}

export enum EMOPLOYEE_ROLES {
  DEFAULT=0,
  CAFE,
  WAITER,
  KITCHAN_MANAGER,
  INVENTORY_MANAGER,
  SWIPPER
}


export enum PRODUCT_CATEGORIES {
    UNKNOWN = 0,
    NORTH_INDIAN=1,
    SOUTH_INDIAN,
    BANGALIES,
    CHINESE,
    PIZZA,
    BURGER,
    ICE_CREAM,
    DRINKING_WATER,
    DESSERTS,
    BIRYANI
}

export enum CAFE_SKILL {
  UNKNOWN = 0,
  NORTH_INDIAN=1,
  SOUTH_INDIAN,
  BANGALIES,
  CHINESE,
  PIZZA,
  BURGER,
  ICE_CREAM,
  DRINKING_WATER,
  DESSERTS,
  BIRYANI
}

export enum PRODUCT_QUALITIES {
    HALF=0,
    MEDIUM=1,
    FULL,
}

export enum ORDER_STATUS {
  PLACED,
  ACCEPTED,
  PREPARING,
  READY_TO_SERVE,
  COMPLETED
}